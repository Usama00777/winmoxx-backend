📦 WinMoxx Fullstack Setup

1. /backend → Upload to GitHub repo `winmoxx-backend` and deploy on Render
2. /frontend → Upload to GitHub repo `winmoxx-frontend` and deploy on Vercel
3. Login Pages:
   - Admin Login: /admin/login
   - Client Login: /client/login

This is your full working structure. Integrate real DB + auth in backend for production.